// lib/routes.dart

class Routes {
  static const String home = '/';
  static const String records = '/records';
  static const String settings = '/settings';
}
