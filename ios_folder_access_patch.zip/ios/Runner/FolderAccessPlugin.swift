// ios/Runner/FolderAccessPlugin.swift
//
// MethodChannel: "cpap.folder_access"
//
// What this fixes:
// - iOS folder picking returns a security-scoped URL.
// - Flutter/dart:io cannot reliably enumerate that external folder directly.
// - We COPY the selected folder into app sandbox (Application Support/ImportedPRS1/<uuid>/...)
//   and return the SANDBOX PATH to Flutter for stable scanning.

import Foundation
import Flutter
import UIKit
import UniformTypeIdentifiers

final class FolderAccessPlugin: NSObject, UIDocumentPickerDelegate {

  private let channel: FlutterMethodChannel
  private weak var presenter: UIViewController?
  private var pendingResult: FlutterResult?

  private let ud = UserDefaults.standard
  private let kBookmark = "cpap_folder_bookmark_b64"
  private let kCopiedPath = "cpap_folder_copied_path"

  init(channel: FlutterMethodChannel, presenter: UIViewController) {
    self.channel = channel
    self.presenter = presenter
    super.init()
    channel.setMethodCallHandler(self.onCall)
  }

  private func onCall(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    switch call.method {
    case "pickFolder":
      pickFolder(result)

    case "restoreBookmark":
      restoreBookmark(result)

    // Optional: allow Dart side to store bookmark if you ever want that flow.
    case "persistBookmark":
      if let args = call.arguments as? [String: Any],
         let b64 = args["bookmark"] as? String,
         !b64.isEmpty {
        ud.set(b64, forKey: kBookmark)
      }
      result(true)

    case "clearBookmark":
      ud.removeObject(forKey: kBookmark)
      ud.removeObject(forKey: kCopiedPath)
      result(true)

    default:
      result(FlutterMethodNotImplemented)
    }
  }

  private func pickFolder(_ result: @escaping FlutterResult) {
    guard pendingResult == nil else {
      result(["granted": false, "path": NSNull(), "bookmark": NSNull(),
              "error": "BUSY: another request is in progress"])
      return
    }
    guard let presenter = presenter else {
      result(["granted": false, "path": NSNull(), "bookmark": NSNull(),
              "error": "NO_PRESENTER"])
      return
    }

    pendingResult = result

    let types: [UTType] = [.folder]
    let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
    picker.allowsMultipleSelection = false
    picker.delegate = self
    presenter.present(picker, animated: true)
  }

  private func restoreBookmark(_ result: @escaping FlutterResult) {
    // Prefer already-copied sandbox path (fast + no prompt).
    if let p = ud.string(forKey: kCopiedPath), FileManager.default.fileExists(atPath: p) {
      result(["granted": true, "path": p])
      return
    }

    guard let b64 = ud.string(forKey: kBookmark),
          let data = Data(base64Encoded: b64) else {
      result(["granted": false, "path": NSNull(), "error": "NO_BOOKMARK"])
      return
    }

    do {
      var stale = false
      let url = try URL(
        resolvingBookmarkData: data,
        options: [.withSecurityScope],
        relativeTo: nil,
        bookmarkDataIsStale: &stale
      )

      // Re-copy into sandbox on restore (keeps Flutter access stable).
      let copied = try withSecurityScoped(url: url) { srcUrl in
        try copyFolderToSandbox(srcUrl)
      }

      ud.set(copied, forKey: kCopiedPath)
      result(["granted": true, "path": copied])
    } catch {
      result(["granted": false, "path": NSNull(), "error": "BOOKMARK_FAIL: \(String(describing: error))"])
    }
  }

  // MARK: - UIDocumentPickerDelegate

  func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
    if let r = pendingResult {
      pendingResult = nil
      r(["granted": false, "path": NSNull(), "bookmark": NSNull(), "error": "CANCELLED"])
    }
  }

  func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
    guard let r = pendingResult else { return }
    pendingResult = nil

    guard let url = urls.first else {
      r(["granted": false, "path": NSNull(), "bookmark": NSNull(), "error": "NO_URL"])
      return
    }

    do {
      // Persist bookmark (so next launch can restore without prompting).
      let bookmarkData = try url.bookmarkData(
        options: [.withSecurityScope],
        includingResourceValuesForKeys: nil,
        relativeTo: nil
      )
      let b64 = bookmarkData.base64EncodedString()
      ud.set(b64, forKey: kBookmark)

      // Copy the whole folder into sandbox.
      let copied = try withSecurityScoped(url: url) { srcUrl in
        try copyFolderToSandbox(srcUrl)
      }
      ud.set(copied, forKey: kCopiedPath)

      r(["granted": true, "path": copied, "bookmark": b64])
    } catch {
      r(["granted": false, "path": NSNull(), "bookmark": NSNull(), "error": "PICK_FAIL: \(String(describing: error))"])
    }
  }

  // MARK: - Helpers

  private func withSecurityScoped<T>(url: URL, _ body: (URL) throws -> T) throws -> T {
    let ok = url.startAccessingSecurityScopedResource()
    defer {
      if ok { url.stopAccessingSecurityScopedResource() }
    }
    return try body(url)
  }

  private func copyFolderToSandbox(_ srcUrl: URL) throws -> String {
    let fm = FileManager.default

    // Ensure Application Support exists.
    let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
    try fm.createDirectory(at: support, withIntermediateDirectories: true, attributes: nil)

    let root = support.appendingPathComponent("ImportedPRS1", isDirectory: true)
    try fm.createDirectory(at: root, withIntermediateDirectories: true, attributes: nil)

    let dest = root.appendingPathComponent(UUID().uuidString, isDirectory: true)

    if fm.fileExists(atPath: dest.path) {
      try fm.removeItem(at: dest)
    }

    try fm.copyItem(at: srcUrl, to: dest)
    return dest.path
  }
}
