// lib/core/utils/path_utils.dart

/// Small path helpers with ZERO extra dependencies.
/// We keep it minimal because this project targets multiple platforms.
///
/// Note: On iOS/Android, paths are POSIX-style.
/// On Windows, paths may contain backslashes. We normalize where needed.

String _norm(String p) => p.replaceAll('\\', '/');

/// Join two path segments with a single '/'.
String joinPath(String a, String b) {
  if (a.isEmpty) return b;
  if (b.isEmpty) return a;
  if (a.endsWith('/') || a.endsWith('\\')) return '$a$b';
  return '$a/$b';
}

/// Get basename of a path.
String basename(String path) {
  final p = _norm(path);
  final idx = p.lastIndexOf('/');
  return idx < 0 ? p : p.substring(idx + 1);
}

/// Compute relative path of [from] to [root].
/// If [from] is not under [root], returns normalized [from] unchanged.
///
/// Example:
///   relativeTo('/a/b', from: '/a/b/c/d.txt') -> 'c/d.txt'
String relativeTo(String root, {required String from}) {
  final r = _norm(root);
  final f = _norm(from);

  final rr = r.endsWith('/') ? r : '$r/';
  if (f == r) return '';
  if (f.startsWith(rr)) return f.substring(rr.length);
  return f;
}

/// Legacy API shim (some files used PathUtils.*).
class PathUtils {
  static String joinPath(String a, String b) => joinPath(a, b);
  static String basename(String path) => basename(path);
  static String relativeTo(String root, {required String from}) => relativeTo(root, from: from);
}
